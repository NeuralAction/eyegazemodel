import os
import codecs

print("init vision")